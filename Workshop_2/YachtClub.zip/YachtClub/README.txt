Author: Sing Trinh, dt222cc@student.lnu.se


Run the application from the executable (shortcut) or from the (visual studio)solution (ctrl+f5).

The members are stored in a file named memberlist.txt inside the folder App_Data.
The application cannot read the file if the content are in some kind of wrong format, for example: an empty field.

For input use "ENTER" to "send" the input. For YES/NO inputs, pressing just "ENTER" works as a (Y)es.

Note:
- I didnt go as far as having the memberId generated automatically.
- I didnt have the social security number (personal number) properly validated.
- Some classes/methods probably have too much responsibility and should be changed, "time".